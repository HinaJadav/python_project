from django.shortcuts import render,HttpResponse

# Create your views here.
def index(request):
    # hina: context is set of all veriables
    # in this we send values from our model or from blog
    context = {
        "variable" : "Priyank" # for example
    }
    return render(request, 'index.html', context)
    # return HttpResponse("This is Homepage")

def about(request):
    return HttpResponse("This is about")

def services(request):
    return HttpResponse("This is services")

def contact(request):
    # if(request.method == "POST"):
    #     name = request.POST.get
    return HttpResponse("This is contact")